bot_token = "" # "bot token" string value
bot_prefix = "." # "bot command prefix" string value

embed_colour = 0x497cf3 # int value ex: 0x497cf3
developers = [00000] # [userid1, userid2, userid3] int value
guild_id = 00000 # int value
buyer_role_id = 00000 # int value
log_channel_id = 00000 # int value

allowHWIDreset = True # False or True allow users to reset there own hwid
HWIDresetamount = 1 # anount of HWID resets per user ( int value )

lg_api_token = "abcdefg" # "luaguard api token" string value
script_id = 11900 # int value
script_name = "Brizzy was here" # string value
script_loadstring = "https://pastebin.com/raw/eeeeee" # "https://pastebin.com/raw/eeeeee" string value

def getscriptfunc(key):
  script = """
_G.wl_key = '"""+key+"""' 
loadstring(game:HttpGet('"""+script_loadstring+"""'))()
"""
  return script