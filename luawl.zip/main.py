import discord
from discord.ext import commands
from time import sleep
from config import *
import json

import luawl

luawl.luawl_token = lg_api_token

bot = commands.Bot(command_prefix=bot_prefix, help_command=None, intents=discord.Intents().all())

async def log(user, command, executor):
  logchannel = bot.get_channel(log_channel_id)
  if not logchannel:
    return
  embed=discord.Embed(title="Command ran!", color=embed_colour)
  embed.add_field(name="Command", value=command, inline=False)
  embed.add_field(name="Target", value=str(user), inline=False)
  embed.add_field(name="Used By", value=str(executor), inline=False)
  embed.set_footer(text="Created by Brizzy#9999")
  await logchannel.send(embed=embed)

@bot.command()
async def claimbuyer(ctx):
  try:
    luawl.get_whitelist(str(ctx.author.id))
  except:
    await ctx.reply(f'No key found for user {ctx.author}!')
    return
  try:
    role = discord.utils.get(ctx.guild.roles, id=buyer_role_id)
    await ctx.author.add_roles(role)
  except:
    await ctx.reply('Failed to give/get role!')
    return
  await ctx.reply(f'Successfully given buyer role to {ctx.author}!')
  await log(ctx.author,'claimbuyer' , ctx.author)

@bot.command()
async def resethwid(ctx, user: discord.User = None):
  if ctx.message.author.id in developers:
    try:
      luawl.reset_hwid(str(user.id))
    except:
      await ctx.reply('Failed to reset HWID could be blacklisted or no HWID added.')
      return
    await ctx.reply('Successfully reset HWID.')
    await log(user, 'resethwid', ctx.author)
  else:
    if allowHWIDreset:
      try:
        used = open(f"info/{ctx.author.id}.txt", "r")
        used = int(used.read())
      except:
        used = 0
      if used < HWIDresetamount:
        try:
          used = open(f"info/{ctx.author.id}.txt", "r")
          used = int(used.read())
          used = int(used+1)
          
          writefile = open(f"info/{ctx.author.id}.txt", "w")
          writefile.write(str(used))
          writefile.close()
        except:
          used = open(f"info/{ctx.author.id}.txt", "w")
          used.write("0")
          used.close()
          used = 0
        try:
          luawl.reset_hwid(str(ctx.author.id))
        except:
          await ctx.reply('Failed to reset HWID could be blacklisted or no HWID added.')
          return
        await ctx.reply(f'Your HWID was reset successfully you have {HWIDresetamount - used} HWID resets left!')
        await log(ctx.author, 'resethwid', ctx.author)
      else:
        await ctx.reply("You do not have any HWID resets left!")
    else:
      e = await ctx.reply('You dont have the required permission!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

@bot.command()
async def removeblacklist(ctx, userorkey):
  if ctx.message.author.id in developers:
    try:
      luawl.get_whitelist(str(userorkey))
    except:
      e = await ctx.reply('User/key not whitelisted! (try using discord id or key)')
      sleep(4)
      e.delete()
      ctx.delete()
      return
    try:
      luawl.remove_blacklist(str(userorkey))
    except:
      e = await ctx.reply('Failed to remove users blacklist!')
      sleep(4)
      e.delete()
      ctx.delete()
      return

    embed=discord.Embed(title="removed blacklist", description="users blacklist has been removed!", color=embed_colour)
    embed.add_field(name="Removed users blacklisted", value="Success!", inline=False)
    embed.set_footer(text="Created by Brizzy#9999")
    await ctx.reply(embed=embed)
    await log(userorkey, 'removeblacklist', ctx.author)
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

@bot.command()
async def blacklist(ctx, userorkey):
  if ctx.message.author.id in developers:
    try:
      luawl.get_whitelist(str(userorkey))
    except:
      e = await ctx.reply('User/key not whitelisted! (try using discord id or key)')
      sleep(4)
      e.delete()
      ctx.delete()
      return
    try:
      luawl.add_blacklist(str(userorkey))
    except:
      e = await ctx.reply('Failed to blacklist user!')
      sleep(4)
      e.delete()
      ctx.delete()
      return
    embed=discord.Embed(title="Blacklisted", description="user's has been blacklisted!", color=embed_colour)
    embed.add_field(name="User blacklisted", value="Success!", inline=False)
    embed.set_footer(text="Created by Brizzy#9999")
    await ctx.reply(embed=embed)
    await log(userorkey, 'blacklist', ctx.author)
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

@bot.command()
async def deletekey(ctx, userorkey):
  if ctx.message.author.id in developers:
    try:
      luawl.get_whitelist(str(userorkey))
    except:
      e = await ctx.reply('User/key not whitelisted! (try using discord id or key)')
      sleep(4)
      e.delete()
      ctx.delete()
      return
    try:
      luawl.delete_whitelist(str(userorkey))
    except:
      e = await ctx.reply('Failed to delete key!')
      sleep(4)
      e.delete()
      ctx.delete()
      return
    embed=discord.Embed(title="Key deleted", description="user's key has been deleted!", color=embed_colour)
    embed.add_field(name="Key deleted", value="Success!", inline=False)
    embed.set_footer(text="Created by Brizzy#9999")
    await ctx.reply(embed=embed)
    await log(userorkey, 'deletekey', ctx.author)
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

@bot.command()
async def getscript(ctx):
  try:
    key = json.loads(str(luawl.get_whitelist(str(ctx.message.author.id))))
    key = key["wl_key"]
  except:
    e = await ctx.reply(f"No key found for user {ctx.message.author}")
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

  try:
    embed=discord.Embed(title="Script", description=f"Here is your script!", color=embed_colour)
    embed.add_field(name="Key", value="`"+key+"`", inline=False)
    embed.add_field(name="Script", value="```"+getscriptfunc(key)+"```", inline=False)
    embed.set_footer(text="Created by Brizzy#9999")
    await ctx.author.send(embed=embed)
    e = await ctx.reply("Check your dms!")
    await log(ctx.author, 'getscript', ctx.author)
    sleep(5)
    await e.delete()
    await ctx.message.delete()
  except:
    e = await ctx.reply("Please turn on your dms!")
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

@bot.command()
async def help(ctx):
  embed=discord.Embed(title="Help", description=f"{ctx.author.name} requested help!", color=embed_colour)
  embed.add_field(name=f"{bot_prefix}whitelist", value="Arguments: <ping user>", inline=False)
  embed.add_field(name=f"{bot_prefix}trialkey", value="Arguments: <ping user>, <Hours>", inline=False)
  embed.add_field(name=f"{bot_prefix}blacklist", value="Arguments: <user id or key>", inline=False)
  embed.add_field(name=f"{bot_prefix}removeblacklist", value="Arguments: <user id or key>", inline=False)
  embed.add_field(name=f"{bot_prefix}deletekey", value="Arguments: <ping user>", inline=False)
  embed.add_field(name=f"{bot_prefix}getinfo", value="Arguments: <ping user>", inline=False)
  embed.add_field(name=f"{bot_prefix}getscript", value="Arguments: None", inline=False)
  embed.add_field(name=f"{bot_prefix}help", value="Arguments: <None>", inline=False)
  embed.add_field(name=f"{bot_prefix}claimbuyer", value="Arguments: <None>", inline=False)
  embed.add_field(name=f"{bot_prefix}resethwid", value="Arguments: <None or ping user>", inline=False)
  embed.set_footer(text="Created by Brizzy#9999")
  await ctx.reply(embed=embed)
  await log(ctx.author, 'Help', ctx.author)
    
@bot.command()
async def trialkey(ctx, user: discord.User, hourstowl=None):
  if ctx.message.author.id in developers:
    try:
      await bot.fetch_user(user.id)
    except:
      e = await ctx.reply('Failed to find user!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    if hourstowl == None:
      e = await ctx.reply('Please state an ammount of hours!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    try:
      int(hourstowl)
    except:
      e = await ctx.reply('Please state an ammount of hours!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    try:
      luawl.get_whitelist(str(user.id))
      e = await ctx.reply('User already whitelisted!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    except:
      
      try:
        userkey = luawl.add_whitelist(str(user.id), str(hourstowl), script_id)

        try:
          embed=discord.Embed(title="Whitelisted", description=f"You have been whitelisted to {script_name}!", color=embed_colour)
          embed.add_field(name="Hours", value="`"+hourstowl+"`", inline=False)
          embed.add_field(name="Key", value="`"+userkey+"`", inline=False)
          embed.add_field(name="Script", value="```"+getscriptfunc(userkey)+"```", inline=False)
          embed.add_field(name=f"Use '{bot_prefix}claimbuyer' to get your role!", value="\u200b", inline=False)
          embed.set_footer(text="Created by Brizzy#9999")
          await user.send(embed=embed)
          
          usernotified = "Success!"
        except:
          usernotified = 'Failed.'

        embed=discord.Embed(title="Whitelisted", description=f"{user} has been whitelisted for {hourstowl} hours!", color=embed_colour)
        embed.add_field(name="User", value=user, inline=False)
        embed.add_field(name="User notified", value=usernotified, inline=False)
        embed.set_footer(text="Created by Brizzy#9999")
        await ctx.reply(embed=embed)
        await log(user, 'trialkey', ctx.author)
        
      except:
        e = await ctx.reply('Failed to whitelist user!')
        sleep(5)
        await e.delete()
        await ctx.message.delete()
        return
        
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return

@bot.command()
async def getinfo(ctx, user: discord.User):
  if ctx.message.author.id in developers:
    try:
      await bot.fetch_user(user.id)
    except:
      e = await ctx.reply('Failed to find user!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    try:
      info = json.loads(str(luawl.get_whitelist(str(user.id))))
      wl_key = info["wl_key"]
      wl_hwid = info["HWID"]
      wl_keystatus = info["key_status"]
      wl_expiredate = info["expiration"]
      wl_hoursremain = info["hours_remaining"]
    except:
      await ctx.reply("User does not have a key!")
    embed=discord.Embed(title="UserInfo", description=f"Userinfo of {user.name}.", color=embed_colour)
        
    embed.add_field(name="Key", value=wl_key, inline=False)
    embed.add_field(name="Hwid", value=wl_hwid, inline=False)
    embed.add_field(name="Key Status", value=wl_keystatus, inline=False)
    embed.add_field(name="Expire date", value=wl_expiredate, inline=False)
    embed.add_field(name="Hours remaining", value=wl_hoursremain, inline=False)
    embed.set_footer(text="Created by Brizzy#9999")
    await ctx.author.send(embed=embed)
    await log(user, 'getinfo', ctx.author)
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return
    
@bot.command()
async def whitelist(ctx, user: discord.User):
  if ctx.message.author.id in developers:
    try:
      await bot.fetch_user(user.id)
    except:
      e = await ctx.reply('Failed to find user!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    try:
      luawl.get_whitelist(str(user.id))
      e = await ctx.reply('User already whitelisted!')
      sleep(5)
      await e.delete()
      await ctx.message.delete()
      return

    except:
      
      try:
        userkey = luawl.add_whitelist(str(user.id), None, script_id)

        try:
          embed=discord.Embed(title="Whitelisted", description=f"You have been whitelisted to {script_name}!", color=embed_colour)
          embed.add_field(name="Key", value="`"+userkey+"`", inline=False)
          embed.add_field(name="Script", value="```"+getscriptfunc(userkey)+"```", inline=False)
          embed.add_field(name=f"Use '{bot_prefix}claimbuyer' to get your role!", value="\u200b", inline=False)
          embed.set_footer(text="Created by Brizzy#9999")
          await user.send(embed=embed)
          
          usernotified = "Success!"
        except:
          usernotified = 'Failed.'

        embed=discord.Embed(title="Whitelisted", description=f"{user} has been whitelisted!", color=embed_colour)
        embed.add_field(name="User", value=user, inline=False)
        embed.add_field(name="User notified", value=usernotified, inline=False)
        embed.set_footer(text="Created by Brizzy#9999")
        await ctx.reply(embed=embed)
        await log(user, 'whitelist', ctx.author)
        
      except:
        e = await ctx.reply('Failed to whitelist user!')
        sleep(5)
        await e.delete()
        await ctx.message.delete()
        return
    
  else:
    e = await ctx.reply('You dont have the required permission!')
    sleep(5)
    await e.delete()
    await ctx.message.delete()
    return
    
@bot.event
async def on_ready():
    print(f'the bot is running with a ping of {round(bot.latency * 1000)} ms')

bot.run(bot_token)